#include <stdio.h>
#include <math.h>

int main(){
    float T71, A71, v71, k71, omega71, x71, y71, t71;

    printf("UTS FISIKA GERAK GELOMBANG\n");
    printf("================================\n");
    printf("NAMA  : MUHAMMAD RACHEL FATHAN IDZHANY\n");
    printf("NPM   : 4522210071\n");
    printf("KELAS : A\n");  
    printf("================================\n");

   // Input data
   printf("\n====================> GERAK GELOMBANG <====================\n");
   printf("Masukkan Nilai periode gelombang             : ");
   scanf("%f", &T71);
   printf("Masukkan Nilai simpangan maksimum meter      : ");
   scanf("%f", &A71);
   printf("Masukkan laju rambat gelombang (v) dalam m/s : ");
   scanf("%f", &v71);
   printf("Masukkan posisi X dalam meter                : ");
   scanf("%f", &x71);
   printf("Masukkan waktu dalam detik                   : ");
   scanf("%f", &t71);

   // Menghitung bilangan gelombang, frekuensi sudut, dan simpangan gelombang
   k71 = 2 * M_PI / (v71* T71);
   omega71 = 2 * M_PI / T71;
   y71 = A71 * sin((omega71*t71) - (k71*x71));
   
   // Menampilkan hasil perhitungan
   printf("\n====================> HASIL <====================\n");
   printf("Bilangan gelombang (k): %.2f m^-1\n", k71);
   printf("Frekuensi sudut (w): %.2f rad/s\n", omega71);
   printf("Simpangan gelombang pada posisi X = %.2f m: %.2f m\n", x71, y71);

   return 0;
}